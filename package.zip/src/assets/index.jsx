import Logo from './Logo.svg'
import Google from './google-2.svg'
import Facebook from './facebook-1.svg'
import Linkedin from './linkedin.svg'
import Arrow2 from './arrrow2.svg'
import Search from './search.svg'
import Gmail from './email.svg'
import Twiter from './twiter.svg'
import Faceboot_rect from './facebook.svg'
import Location from './location.svg'
import Eye from './eye.svg'
import Pencil from './pencil.svg'
import Delete from './delete.svg'

export {
    Logo,
    Google,
    Facebook,
    Linkedin,
    Arrow2,
    Search,
    Location,
    Faceboot_rect,Gmail,Twiter,
    Eye,Pencil,Delete,

}