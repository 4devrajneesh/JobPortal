import React from "react";
import Accordion from "react-bootstrap/Accordion";
import AlljobsComponent from "./AlljobsComponent";

function FindjobLayout() {
  return (
    <div className="container">
 
    <div className="row">
      <div className="col-12 col-md-4 col-lg-3 p-1">
        <Accordion defaultActiveKey="0">
          <Accordion.Item eventKey="0" >
            <Accordion.Header ><p className=" fw600 font20">Job Type</p></Accordion.Header>
            <Accordion.Body>
              <div className="form-check">
                <input
                  className="form-check-input me-3"
                  type="checkbox"
                  defaultValue=""
                  id="flexCheckDefault"
                />
                <label
                  className="form-check-label fw400 font18"
                  htmlFor="flexCheckDefault"
                >
                  Full time
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input me-3"
                  type="checkbox"
                  defaultValue=""
                  id="flexCheckChecked"
                  defaultChecked=""
                />
                <label
                  className="form-check-label fw400 font18"
                  htmlFor="flexCheckChecked"
                >
                  Part time
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input me-3"
                  type="checkbox"
                  defaultValue=""
                  id="flexCheckDefault"
                />
                <label
                  className="form-check-label fw400 font18"
                  htmlFor="flexCheckDefault"
                >
                  Remote
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input me-3"
                  type="checkbox"
                  defaultValue=""
                  id="flexCheckDefault"
                />
                <label
                  className="form-check-label fw400 font18"
                  htmlFor="flexCheckDefault"
                >
                  Internship
                </label>
              </div>
              <div className="form-check">
                <input
                  className="form-check-input me-3"
                  type="checkbox"
                  defaultValue=""
                  id="flexCheckDefault"
                />
                <label
                  className="form-check-label fw400 font18"
                  htmlFor="flexCheckDefault"
                >
                  Contract
                </label>
              </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>





        <Accordion defaultActiveKey="1">
          <Accordion.Item eventKey="1" >
            <Accordion.Header> <p className=" fw600 font20">Job Categories</p></Accordion.Header>
            <Accordion.Body>
          
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckChecked"
                      defaultChecked=""
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckChecked"
                    >
                     Design
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckChecked"
                      defaultChecked=""
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckChecked"
                    >
                      Sales
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckDefault"
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckDefault"
                    >
                      Marketting
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckDefault"
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckDefault"
                    >
                      Finance
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckDefault"
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckDefault"
                    >
                      Technology
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckDefault"
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckDefault"
                    >
                      Engineering
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckDefault"
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckDefault"
                    >
                      Business
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckDefault"
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckDefault"
                    >
                      Human Resource
                    </label>
                  </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>




        <Accordion defaultActiveKey="2">
          <Accordion.Item eventKey="2" >
            <Accordion.Header><p className=" fw600 font20 p-0"> Salary Range</p></Accordion.Header>
            <Accordion.Body>
            <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckDefault"
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckDefault"
                    >
                      $5 - $100
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckChecked"
                      defaultChecked=""
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckChecked"
                    >
                      $100 - $1000
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckDefault"
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckDefault"
                    >
                      $1000 - $5000
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input me-3"
                      type="checkbox"
                      defaultValue=""
                      id="flexCheckDefault"
                    />
                    <label
                      className="form-check-label fw400 font18"
                      htmlFor="flexCheckDefault"
                    >
                      $5000 and above
                    </label>
                  </div>
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>




       



      </div>
      <div className="col-12 col-md-8 col-lg-9 pt-3">
      <div className="d-flex justify-content-between">
          <div className="">
            <h2 className="mb-0 font25 fw600 showing">All Jobs</h2>
            <p className="fw400 font18 result mt-0">Showing 22 results</p>
          </div>
          <div className="">
            <p className="mb-0 fw600 relevant">
              Sort by <span className="most-relevant">: Most relevant</span>
            </p>
          </div>
        </div>
<AlljobsComponent/>
      </div>
    </div>
    </div>
  );
}

export default FindjobLayout;
