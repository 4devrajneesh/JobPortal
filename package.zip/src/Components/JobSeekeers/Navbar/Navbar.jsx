import React, { useState, useEffect } from "react";
import { Logo } from "../../.././assets";
import { Link } from "react-router-dom";
function Navbar() {
  const [scrollPosition, setScrollPosition] = useState(0);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const handleScroll = () => {
    const currentPosition = window.pageYOffset;
    setScrollPosition(currentPosition);
  };
  return (
    <div>
      <div className="header-banner ">
        <header className="site-header">
          <div
            className={`top-header  py-3 ${
              scrollPosition >= 37 ? "position-fixed" : ""
            }`}
          >
            <nav className="navbar navbar-expand-lg navbar-light py-0">
              <div className="container">
                <div className="logo">
                  <Link className="navbar-brand" to="/">
                    <img src={Logo} alt="logo" />
                  </Link>
                </div>

                <div
                  className="navbar-collapse justify-content-end collapse"
                  id="navbarSupportedContent"
                >
                  For employers
                </div>
              </div>
            </nav>
          </div>
        </header>
      </div>
    </div>
  );
}

export default Navbar;
