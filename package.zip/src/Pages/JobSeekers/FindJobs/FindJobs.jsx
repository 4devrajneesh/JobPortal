import React from 'react'
import Navbar from '../../../Components/JobSeekeers/NavbarMain/Navbar'
import {Search,Location} from "../../../assets"
import Recommended from '../../../Components/JobSeekeers/FindJobs/Recommended'
import Footer from '../../../Components/JobSeekeers/Footer/Footer'
import AllJobs from '../../../Components/JobSeekeers/FindJobs/AllJobs'
import './findjobs.css'
import FindjobLayout from '../../../Components/JobSeekeers/FindJobs/FindjobLayout'
function FindJobs() {
  return (
    <>
      <Navbar/>
 <section className="job-lisiting py-5">
  <div className="container ">
    <h1 className="fw500 font30 text-center">
      Discover more than<span className="jobs-color"> 50+ jobs</span>
    </h1>
    <form className="align-items-center d-md-flex justify-content-center pt-4">
      <div className="search-txt border rounded-3 ps-0 ps-md-3">
        <img src={Search} alt="search image" />
        <input
          type="text"
          placeholder="Enter  job title, keyword"
          className="border-0  find-job-inp bg-transparent search-job"
        />
      </div>
      <div className="search-txt border rounded-3 mx-5 ps-0 ps-md-3">
        <img src={Location} alt="location" />
        <input
          type="text"
          placeholder="Location"
          className="border-0 find-job-inp bg-transparent"
        />
      </div>
      <div className="search-box">
        <button
          type="submit"
          className="text-white mt-3 mt-md-0 border-0 d-flex align-items-center"
        >
          Search
        </button>
      </div>
    </form>
    <p className="text-gray pt-3 form-text-1 form-check-label fw400 font18">
      Popular searches : UI Designer, UX Researcher, Android, Admin
    </p>
  </div>
</section>
{/* <AllJobs/> */}
<FindjobLayout/>
<Recommended/>
<Footer/>
    </>
  )
}

export default FindJobs
